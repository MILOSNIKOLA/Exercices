
/* Le débogueur */

/*

Il n'y a pas de cours ni d'exercices pour le débogueur.

Entraînez-vous à l'utiliser sur des petits programmes que vous aurez rédigé
ou récupéré sur Internet.

Pensez à lire la documention de chaque débogueur !
Doc (en Anglais) débogueur Chrome : https://developers.google.com/web/tools/chrome-devtools/javascript
Doc (en Anglais) débogueur VSCode : https://code.visualstudio.com/Docs/editor/debugging

Bon débogage :) !

*/