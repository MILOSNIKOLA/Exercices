/*
 * N'hésitez pas à jeter un oeil 👁 sur ce code et à me prévenir
 * si vous rencontrez un bogue !
 *
 * Vous pouvez me joindre par email sur jeremy@javascriptdezero.com.
 *
 * Merci 👍
 */

/* eslint-disable no-unused-vars */

/* globals reponsesEnonces */
const reponsesEnonces = [
  false,
  true,
  true,
  true,
  false,
];
