/*
 * Tapez votre code sous chacun des commentaires.
 * Vous devez faire les exercices dans l'ordre !
 *
 * Si vous rencontrez un bogue, contactez-moi par email à l'adresse
 * jeremy@javascriptdezero.com.
 *
 * Merci et bon courage ! 🤘
 */

// Exercice 0

// Exercice 1

// Exercice 2

// Exercice 3

// Exercice 4

// Chassez le bogue 0
// Retirez les commentaires devant le code de Tom pour commencer
// console.log(2350 - (1000 + 2350) * 12 / 100);

// Chassez le bogue 1
// Retirez les commentaires devant le code de Tom pour commencer
// console.log('Montant récolté auprès des 5 investisseurs : 5 x 470 = ' + 15 * 470 + ' €\nMontant récolté auprès de 10 amis : 10 x 100 = ' + 10 * -100 + ' €\nMontant total récolté : 2350 + 1000 = ' + 2350 + ' 1000 €\nBénéfice net (après le prélèvement des taxes) : 2350 - 2350 * 0.12 + 1000 = ' + (2350 - 2350) * 0.12 + 1000 + ' €');
