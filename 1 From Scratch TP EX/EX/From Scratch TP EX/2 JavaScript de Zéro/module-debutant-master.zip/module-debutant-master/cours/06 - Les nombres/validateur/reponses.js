/*
 * N'hésitez pas à jeter un oeil 👁 sur ce code et à me prévenir
 * si vous rencontrez un bogue !
 *
 * Vous pouvez me joindre par email sur jeremy@javascriptdezero.com.
 *
 * Merci 👍
 */

/* eslint-disable no-unused-vars */

/* globals reponsesEnonces */
const reponsesEnonces = [
  34,
  13,
  3186,
  2889.5,
  18,
  3068,
  `Montant récolté auprès des 5 investisseurs : 5 x 470 = 2350 €
Montant récolté auprès de 10 amis : 10 x 100 = 1000 €
Montant total récolté : 2350 + 1000 = 3350 €
Bénéfice net (après le prélèvement des taxes) : 2350 - 2350 * 0.12 + 1000 = 3068 €`,
];
