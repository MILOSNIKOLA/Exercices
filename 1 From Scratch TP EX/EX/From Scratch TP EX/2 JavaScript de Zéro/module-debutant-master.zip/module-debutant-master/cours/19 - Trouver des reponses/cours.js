/* Trouver des réponses sur Internet */

// Résoudre un problème de syntaxe
function souhaiterLaBienvenue(prenom) {
  console.log("Bienvenue ' + prenom + " dans cette formation !");
}

// Résoudre un problème fonctionnel
// function estCeZero(chiffre) {
//   console.log("Est-ce que le chiffre " + chiffre + " est zéro ?");
//   if (chiffre = 0) {
//     console.log("Bien sûr que oui, c'est zéro !");
//   } else {
//     console.log("Non, ce n'est pas zéro 😭");
//   }
// }

// estCeZero(0);
