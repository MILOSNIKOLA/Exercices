/*
 * Tapez votre code sous chacun des commentaires.
 * Vous devez faire les exercices dans l'ordre !
 *
 * Si vous rencontrez un bogue, contactez-moi par email à l'adresse
 * jeremy@javascriptdezero.com.
 *
 * Merci et bon courage ! 🤘
 */

// Exercice 0

// Exercice 1

// Exercice 2

// Exercice 3

// Exercice 4

// Exercice 5

// Chassez le bogue 0
// Retirez les commentaires devant le code de Tom pour commencer
// console.log("Bonjour' + 'Bob' + ', aujourd'hui nous faisons une promo 'la fidélité paye' !");

// Chassez le bogue 1
// Retirez les commentaires devant le code de Tom pour commencer (les 3 lignes ci-dessous)
// console.log('        Bonjour' + 'Bob' + ",  \
// \
// Aujourd\'hui nous faisons une promo \"la fidélité paye\" !");
